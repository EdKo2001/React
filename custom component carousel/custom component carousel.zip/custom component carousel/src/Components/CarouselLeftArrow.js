import React, { Component } from 'react';
import { GrPrevious } from 'react-icons/gr'

class CarouselLeftArrow extends Component {
    render() {
        return (
            <a
                href="#"
                className="carousel__arrow carousel__arrow--left"
                onClick={this.props.onClick}
            >
               <GrPrevious />
            </a>
        );
    }
}

export default CarouselLeftArrow;