import React, { Component } from 'react';
import { GrNext } from 'react-icons/gr'

class CarouselRightArrow extends Component {
    render() {
        return (
            <a
                href="#"
                className="carousel__arrow carousel__arrow--right"
                onClick={this.props.onClick}
            >
                <GrNext />
            </a>
        );
    }
}


export default CarouselRightArrow;